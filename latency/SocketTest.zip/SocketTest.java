import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class SocketTest implements Runnable{

    protected int          serverPort   = 8080;
    protected ServerSocket serverSocket = null;
    protected boolean      isStopped    = false;
    protected Thread       runningThread= null;

    public SocketTest(int port){
        this.serverPort = port;
    }

    public void run(){
        synchronized(this){
            this.runningThread = Thread.currentThread();
        }
        openServerSocket();

        while(! isStopped()){
            Socket clientSocket = null;
            try {
                clientSocket = this.serverSocket.accept();
            } catch (IOException e) {
                if(isStopped()) {
                    System.out.println("Server Stopped.") ;
                    return;
                }
                throw new RuntimeException(
                    "Error accepting client connection", e);
            }
            try {
                processClientRequest(clientSocket);
            } catch (Exception e) {
                //log exception and go on to next request.
            }
        }

        System.out.println("Server Stopped.");
    }

    private void processClientRequest(Socket clientSocket)
    throws Exception {
        InputStream  input  = clientSocket.getInputStream();
        OutputStream output = clientSocket.getOutputStream();
        long time = System.currentTimeMillis();
        String rd = "<html><body>SocketTest Server listening on port " + serverPort + " : " + time + "</body></html>";
        byte[] responseDocument = rd.getBytes("UTF-8");

        String rh = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: " + responseDocument.length + "\r\n\r\n";
        byte[] responseHeader = rh.getBytes("UTF-8");


        output.write(responseHeader);
        output.write(responseDocument);
        output.close();
        input.close();
        System.out.println("Request processed: " + time);
    }

    private synchronized boolean isStopped() {
        return this.isStopped;
    }

    public synchronized void stop(){
        this.isStopped = true;
        try {
            this.serverSocket.close();
        } catch (IOException e) {
            throw new RuntimeException("Error closing server", e);
        }
    }

    private void openServerSocket() {
        try {
            this.serverSocket = new ServerSocket(this.serverPort);
        } catch (IOException e) {
            throw new RuntimeException("Cannot open port 8080", e);
        }
    }

    public static void main(String[] args) {

      if (args.length==0) {
        usage();
        print("Fatal - missing parameter port");
        System.exit(1);
      }

      String myPort = args[0];

      int pn = 0;

      try{
        pn = Integer.parseInt(args[0]);
      }
      catch (Exception e) {
        print("Error - " + args[0] + " cannot be parsed as a port");
        usage();
        System.exit(1);
      }

      print("Attempting to start server on port " + pn);



      SocketTest st = new SocketTest(pn);
      Thread t = new Thread(st);
      t.start();
      print("Server process started");
      print("Enter <Ctrl><C> to stop the test");
    }

    public static void usage() {
      print("Usage:");
      print("java -cp . SocketTest [port_number]");
      print(" ");
      print("[port_number] should be a numeric string in the range 1-65535");
      print("If you need to test any privileged port (<1024) you need to run this as root");
      print("This program assumes java is in the path");
      print("To test, open a browser and point to http://server:[port_number]/ and you will get a response");
      print("questions, feedback: gustavo.j.jimenez@accenture.com");
    }

    public static void print(String msg) {
      System.out.println(msg);
    }

}
