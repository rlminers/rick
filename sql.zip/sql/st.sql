show parameter sga
show parameter memory
show parameter pga
show parameter filesystem
show parameter processes
@@redo_logs

