
drop role GLUENT_OFFLOAD_SQLMON_ROLE;
drop role GLUENT_OFFLOAD_REPO_ROLE;
drop role GLUENT_OFFLOAD_ROLE;

drop user gluent_adm cascade;
drop user gluent_app cascade;
drop user gluent_repo cascade;

