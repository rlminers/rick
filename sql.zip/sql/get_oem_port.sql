
SELECT DBMS_XDB_CONFIG.gethttpsport FROM dual;

--exec dbms_xdb_config.SETHTTPSPORT(x);

