#!/bin/bash
filelist=`ls -1 *.log`
# filelist="offload_CAMDBA.GG_CUSTOMER_ACTIVITY_S0_2020-10-16T11_15_01.694948.log"
printf "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n" "table_name" "rows_offloaded" "sum_part" "sum_chunks" "sum_transport_secs" "sum_avro_bytes" "sum_validate_staged_data" "sum_validate_types" "sum_insert_secs" "sum_bytes_processed" "sum_bytes_billed" "sum_verify_exported_data" "other_secs" "total_secs" "FILENAME"
for cf in $filelist ; do
  awk -f parse-offload-logs.awk ${cf}
done
