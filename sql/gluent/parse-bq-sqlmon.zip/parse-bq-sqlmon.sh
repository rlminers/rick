#!/bin/bash

scrdir="/home/oracle/Downloads/sqlmon"

printf "%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s" "duration" "elapsed" "cpu" "io" "other" "fetch_count" "oracle_rows" "buffer_gets" "diskreads" "read_reqs" "read_bytes" "filename" 
printf "~%s~%s~%s~%s~%s~%s~%s\n" "sqlid" "slots" "cr_time" "end_time" "slot_millis" "total_bytes_billed" "total_bytes_proc"

filelist=`grep -l '"plan"' sqlmon*.html`
for cur_file in ${filelist} ; do
  part_o=`awk -f ${scrdir}/parse-sqlmon.awk ${cur_file}`
  part_bq=`grep '"plan"' ${cur_file} | sed -f ${scrdir}/parse-bq-sqlmon.sed | sed '/^$/d' | awk -F = -f ${scrdir}/parse-bq-sqlmon.awk`
  echo "${part_o}~${part_bq}"
done
exit 0
# end of file
